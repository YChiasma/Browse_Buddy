// Placeholder - no background logic needed for now.
